/* eslint-disable no-undef */
// Game state
let blocks = 0;
let buildingsBuilt = 0;
let currentEquation = { num1: 0, num2: 0, operation: '+', answer: 0 };
let isDaytime = true;
let currentDifficulty = 0;
let correctAnswersCount = 0;
let buildingHistory = [];
const MAX_HISTORY_STEPS = 7;
let draggedBlock = null;
let offsetX, offsetY;

// Game difficulty levels
const difficultyLevels = [
    {
        name: "Beginner",
        operations: ['+'],
        maxNumber: 5,
        blocksPerPoint: 1,
        specialBlockChance: 0.05,
        minBuildings: 0
    },
    {
        name: "Easy",
        operations: ['+', '-'],
        maxNumber: 10,
        blocksPerPoint: 1.2,
        specialBlockChance: 0.07,
        minBuildings: 5
    },
    {
        name: "Medium",
        operations: ['+', '-'],
        maxNumber: 15,
        blocksPerPoint: 1.5,
        specialBlockChance: 0.1,
        minBuildings: 15
    },
    {
        name: "Hard",
        operations: ['+', '-', '×'],
        maxNumber: 20,
        blocksPerPoint: 1.8,
        specialBlockChance: 0.15,
        minBuildings: 30
    },
    {
        name: "Expert",
        operations: ['+', '-', '×', '÷'],
        maxNumber: 30,
        blocksPerPoint: 2,
        specialBlockChance: 0.2,
        minBuildings: 50
    }
];

// Colors and special blocks
const colors = ['#e74c3c', '#3498db', '#f1c40f', '#2ecc71', '#9b59b6'];
const specialBlocks = {
    rainbow: {
        color: 'linear-gradient(45deg, red, orange, yellow, green, blue, indigo, violet)',
        points: 10,
        emoji: '🌈'
    },
    gold: {
        color: 'gold',
        points: 5,
        emoji: '🌟'
    },
    diamond: {
        color: 'cyan',
        points: 3,
        emoji: '💎'
    }
};

// Unlockable characters
const characters = [
    { name: "Color Fairy", unlocked: true, emoji: "🧚", desc: "Helps with colors!", requirement: 0 },
    { name: "Math Wizard", unlocked: false, emoji: "🧙", desc: "Makes math easier!", requirement: 50 },
    { name: "Block Robot", unlocked: false, emoji: "🤖", desc: "Builds faster!", requirement: 100 },
    { name: "Rainbow Unicorn", unlocked: false, emoji: "🦄", desc: "Magical builder!", requirement: 200 }
];

// DOM elements
const equationEl = document.getElementById('equation');
const answerInput = document.getElementById('answer-input');
const submitBtn = document.getElementById('submit-btn');
const blockCountEl = document.getElementById('block-count');
const blocksContainer = document.getElementById('blocks-container');
const cityCanvas = document.getElementById('city-canvas');
const progressFill = document.getElementById('progress-fill');
const progressText = document.getElementById('progress-text');
const difficultyLevelEl = document.getElementById('difficulty-level');
const minigameBtn = document.getElementById('minigame-btn');
const unlockedCharactersEl = document.getElementById('unlocked-characters');
const professorImg = document.getElementById('professor');
const speechBubble = document.getElementById('speech-bubble');
const undoBtn = document.getElementById('undo-btn');
const resetBtn = document.getElementById('reset-btn');

// Create a hidden drag image to suppress default ghost image
const dragImage = document.createElement('div');
dragImage.style.width = '1px';
dragImage.style.height = '1px';
dragImage.style.opacity = '0';
document.body.appendChild(dragImage);

// Event tracking function
function trackEvent(eventName, details = {}) {
    const timestamp = new Date().toISOString();
    console.log(`[Mathopolis Event] ${eventName} at ${timestamp}`, details);
}

// Save game state to local storage with confirmation for large states
function saveGameState() {
    const gameState = {
        blocks,
        buildingsBuilt,
        currentDifficulty,
        correctAnswersCount,
        characters: characters.map(char => ({ ...char })),
        buildingHistory: buildingHistory.map(action => ({
            value: action.value,
            x: action.element ? parseInt(action.element.style.left) : null,
            y: action.element ? parseInt(action.element.style.top) : null,
            background: action.element ? action.element.style.background : null,
            emoji: action.element ? action.element.innerHTML : null
        }))
    };
    const serializedState = JSON.stringify(gameState);
    const stateSizeKB = new Blob([serializedState]).size / 1024;

    if (stateSizeKB > 50) {
        if (!confirm(`The game state is large (${Math.round(stateSizeKB)}KB). Saving may impact performance on some devices. Continue?`)) {
            trackEvent('save_cancelled', { stateSizeKB });
            return;
        }
    }

    localStorage.setItem('mathopolisState', serializedState);
    trackEvent('game_state_saved', { stateSizeKB, blocks, buildingsBuilt, currentDifficulty });
}

// Load game state from local storage
function loadGameState() {
    const savedState = localStorage.getItem('mathopolisState');
    if (savedState) {
        const gameState = JSON.parse(savedState);
        blocks = gameState.blocks || 0;
        buildingsBuilt = gameState.buildingsBuilt || 0;
        currentDifficulty = gameState.currentDifficulty || 0;
        correctAnswersCount = gameState.correctAnswersCount || 0;
        characters.forEach((char, index) => {
            char.unlocked = gameState.characters[index]?.unlocked || char.unlocked;
        });
        buildingHistory = gameState.buildingHistory.map(action => {
            if (action.x !== null && action.y !== null) {
                const block = document.createElement('div');
                block.className = 'city-block';
                block.style.background = action.background;
                block.style.position = 'absolute';
                block.style.left = `${action.x}px`;
                block.style.top = `${action.y}px`;
                block.innerHTML = action.emoji;
                block.draggable = true;
                block.dataset.value = action.value;
                block.setAttribute('aria-label', 'Placed building block');
                block.setAttribute('role', 'button');
                setupCityBlockEvents(block);
                cityCanvas.appendChild(block);
                return { element: block, value: action.value };
            }
            return { value: action.value };
        });
        blockCountEl.textContent = blocks;
        updateProgress();
        updateDifficultyDisplay();
        updateUnlockedCharacters();
        trackEvent('game_state_loaded', { blocks, buildingsBuilt, currentDifficulty });
    }
}

// Reset game state
function resetGame() {
    if (confirm('Are you sure you want to reset your game? All progress will be lost.')) {
        blocks = 0;
        buildingsBuilt = 0;
        currentDifficulty = 0;
        correctAnswersCount = 0;
        buildingHistory = [];
        characters.forEach(char => char.unlocked = char.name === "Color Fairy");
        while (cityCanvas.firstChild) {
            cityCanvas.removeChild(cityCanvas.firstChild);
        }
        while (blocksContainer.firstChild) {
            blocksContainer.removeChild(blocksContainer.firstChild);
        }
        localStorage.removeItem('mathopolisState');
        blockCountEl.textContent = blocks;
        updateProgress();
        updateDifficultyDisplay();
        updateUnlockedCharacters();
        generateNewEquation();
        showMessage("Game reset! Start building your Mathopolis!");
        trackEvent('game_reset');
    }
}

// Sound functions with fallback
function playSound(soundId) {
    try {
        const sound = document.getElementById(soundId);
        if (sound) {
            sound.currentTime = 0;
            sound.play().catch(e => {
                console.log("Sound playback prevented:", e);
                trackEvent('sound_playback_failed', { soundId, error: e.message });
            });
        }
    } catch (e) {
        console.log("Sound error:", e);
        trackEvent('sound_error', { soundId, error: e.message });
    }
}

function playCorrectSound() {
    playSound('correct-sound');
}

function playBuildSound() {
    playSound('build-sound');
}

function playUnlockSound() {
    playSound('unlock-sound');
}

function playCelebrationSound() {
    playSound('celebration-sound');
}

// Initialize game
function initGame() {
    if (!equationEl || !answerInput || !submitBtn || !blockCountEl || !blocksContainer || !cityCanvas ||
        !progressFill || !progressText || !difficultyLevelEl || !minigameBtn || !unlockedCharactersEl ||
        !professorImg || !speechBubble || !undoBtn || !resetBtn) {
        console.error("One or more DOM elements are missing!");
        trackEvent('init_error', { message: 'Missing DOM elements' });
        return;
    }
    loadGameState();
    generateNewEquation();
    setupEventListeners();
    updateProgress();
    startDayNightCycle();
    showMessage("Welcome to Mathopolis! Solve math problems to build your city!");
    updateDifficultyDisplay();
    updateUnlockedCharacters();
    trackEvent('game_initialized');
}

// Update difficulty display
function updateDifficultyDisplay() {
    if (difficultyLevelEl) {
        difficultyLevelEl.textContent = `Level: ${difficultyLevels[currentDifficulty].name}`;
        trackEvent('difficulty_updated', { level: difficultyLevels[currentDifficulty].name });
    }
}

// Generate random math problem based on current difficulty
function generateNewEquation() {
    const difficulty = difficultyLevels[currentDifficulty];
    const operation = difficulty.operations[Math.floor(Math.random() * difficulty.operations.length)];
    
    let num1, num2, answer;
    let validEquation = false;
    
    const difficultyScale = Math.min(2, 1 + (buildingsBuilt / 100));
    
    while (!validEquation) {
        switch (operation) {
            case '+':
                num1 = Math.floor(Math.random() * difficulty.maxNumber * difficultyScale) + 1;
                num2 = Math.floor(Math.random() * difficulty.maxNumber * difficultyScale) + 1;
                answer = num1 + num2;
                validEquation = true;
                break;
            case '-':
                num1 = Math.floor(Math.random() * difficulty.maxNumber * difficultyScale) + 1;
                num2 = Math.floor(Math.random() * num1) + 1;
                answer = num1 - num2;
                validEquation = answer > 0;
                break;
            case '×':
                num1 = Math.floor(Math.random() * 10 * difficultyScale) + 1;
                num2 = Math.floor(Math.random() * 10 * difficultyScale) + 1;
                answer = num1 * num2;
                validEquation = true;
                break;
            case '÷':
                answer = Math.floor(Math.random() * 10 * difficultyScale) + 1;
                num2 = Math.floor(Math.random() * 5 * difficultyScale) + 1;
                num1 = answer * num2;
                validEquation = num2 !== 0;
                break;
        }
    }
    
    currentEquation = { num1, num2, operation, answer };
    
    const displayOperation = operation === '×' ? '×' : operation === '÷' ? '÷' : operation;
    if (equationEl) {
        equationEl.innerHTML = `${num1} ${displayOperation} ${num2} = ?`;
    }
    if (answerInput) {
        answerInput.value = '';
        answerInput.focus();
    }
    trackEvent('new_equation', { equation: `${num1} ${displayOperation} ${num2}`, difficulty: difficulty.name });
}

// Check player's answer
function checkAnswer() {
    const playerAnswer = parseInt(answerInput.value);
    
    if (isNaN(playerAnswer) || answerInput.value.trim() === '') {
        showMessage("Please enter a valid number!");
        answerInput.classList.add('shake');
        setTimeout(() => answerInput.classList.remove('shake'), 500);
        trackEvent('invalid_answer', { input: answerInput.value });
        return;
    }
    
    if (playerAnswer === currentEquation.answer) {
        playCorrectSound();
        correctAnswersCount++;
        answerInput.classList.add('correct');
        setTimeout(() => answerInput.classList.remove('correct'), 1000);
        
        const difficulty = difficultyLevels[currentDifficulty];
        const blocksEarned = Math.max(1, Math.floor(currentEquation.answer * difficulty.blocksPerPoint));
        
        blocks += blocksEarned;
        blockCountEl.textContent = blocks;
        
        createNewBlocks(blocksEarned);
        
        if ((correctAnswersCount >= 5 || buildingsBuilt >= difficultyLevels[currentDifficulty].minBuildings) && 
            currentDifficulty < difficultyLevels.length - 1) {
            currentDifficulty++;
            correctAnswersCount = 0;
            showMessage(`Level up! Now at ${difficultyLevels[currentDifficulty].name} difficulty!`);
            updateDifficultyDisplay();
            trackEvent('level_up', { newLevel: difficultyLevels[currentDifficulty].name });
        }
        
        celebrate();
        generateNewEquation();
        checkUnlocks();
        updateProgress();
        saveGameState();
        
        const comments = [
            "Great job!",
            `You earned ${blocksEarned} blocks!`,
            "Math genius!",
            "Keep it up!"
        ];
        showMessage(comments[Math.floor(Math.random() * comments.length)]);
        trackEvent('correct_answer', { equation: `${currentEquation.num1} ${currentEquation.operation} ${currentEquation.num2}`, answer: playerAnswer, blocksEarned });
    } else {
        showMessage(`Oops! The correct answer is ${currentEquation.answer}. Try again!`);
        answerInput.classList.add('wrong');
        setTimeout(() => answerInput.classList.remove('wrong'), 1000);
        answerInput.value = '';
        answerInput.focus();
        trackEvent('wrong_answer', { equation: `${currentEquation.num1} ${currentEquation.operation} ${currentEquation.num2}`, playerAnswer, correctAnswer: currentEquation.answer });
    }
}

// Check for block overlap
function isOverlapping(x, y, width = 55, height = 55) {
    const blocks = cityCanvas.querySelectorAll('.city-block');
    for (const block of blocks) {
        const rect = block.getBoundingClientRect();
        const canvasRect = cityCanvas.getBoundingClientRect();
        const blockX = rect.left - canvasRect.left;
        const blockY = rect.top - canvasRect.top;
        if (x < blockX + 55 && x + width > blockX && y < blockY + 55 && y + height > blockY) {
            return true;
        }
    }
    return false;
}

// Enhanced block creation and display system
function createNewBlocks(count) {
    const visualBlocks = Math.min(count, 15);
    const difficulty = difficultyLevels[currentDifficulty];
    
    let blocksWrapper = blocksContainer.querySelector('.blocks-wrapper');
    if (!blocksWrapper) {
        blocksWrapper = document.createElement('div');
        blocksWrapper.className = 'blocks-wrapper';
        blocksWrapper.style.display = 'flex';
        blocksWrapper.style.flexWrap = 'wrap';
        blocksWrapper.style.justifyContent = 'center';
        blocksWrapper.style.gap = '10px';
        blocksWrapper.style.padding = '10px';
        blocksWrapper.style.maxHeight = '200px';
        blocksWrapper.style.overflowY = 'auto';
        blocksWrapper.style.backgroundColor = 'rgba(255,255,255,0.7)';
        blocksWrapper.style.borderRadius = '10px';
        blocksWrapper.style.margin = '10px 0';
        blocksWrapper.style.border = '2px solid #3498db';
        
        const blocksTitle = document.createElement('h4');
        blocksTitle.textContent = 'Drag Blocks to Build:';
        blocksTitle.style.margin = '0 0 10px 0';
        blocksTitle.style.textAlign = 'center';
        blocksTitle.style.color = '#2c3e50';
        blocksContainer.appendChild(blocksTitle);
        blocksContainer.appendChild(blocksWrapper);
    }
    
    for (let i = 0; i < visualBlocks; i++) {
        const block = document.createElement('div');
        block.className = 'block';
        block.style.transition = 'all 0.2s ease';
        block.style.cursor = 'grab';
        block.style.userSelect = 'none';
        block.setAttribute('aria-label', 'Draggable building block');
        block.setAttribute('role', 'button');
        
        if (Math.random() < difficulty.specialBlockChance) {
            const specialTypes = Object.keys(specialBlocks);
            const specialType = specialTypes[Math.floor(Math.random() * specialTypes.length)];
            block.style.background = specialBlocks[specialType].color;
            block.dataset.value = Math.ceil(specialBlocks[specialType].points * (currentDifficulty + 1));
            block.innerHTML = specialBlocks[specialType].emoji;
            block.style.boxShadow = '0 0 10px rgba(255,255,255,0.7)';
        } else {
            const color = colors[Math.floor(Math.random() * colors.length)];
            block.style.background = color;
            block.dataset.value = 1;
            block.innerHTML = '⬜';
            block.style.boxShadow = `0 0 5px ${color}`;
        }
        
        block.style.opacity = '0';
        block.style.transform = 'scale(0.8)';
        setTimeout(() => {
            block.style.opacity = '1';
            block.style.transform = 'scale(1)';
        }, 100 * i);
        
        block.draggable = true;
        block.addEventListener('dragstart', (e) => {
            e.dataTransfer.setDragImage(dragImage, 0, 0);
            e.dataTransfer.setData('text/plain', block.style.background);
            e.dataTransfer.setData('value', block.dataset.value);
            e.dataTransfer.setData('emoji', block.innerHTML);
            block.style.transform = 'scale(1.2) rotate(5deg)';
            block.style.opacity = '0.8';
            block.style.zIndex = '1000';
            draggedBlock = block;
            trackEvent('block_drag_start', { value: block.dataset.value });
        });
        
        block.addEventListener('dragend', () => {
            block.style.transform = '';
            block.style.opacity = '';
            block.style.zIndex = '';
            draggedBlock = null;
            trackEvent('block_drag_end');
        });
        
        block.addEventListener('touchstart', (e) => {
            e.preventDefault();
            draggedBlock = block;
            const touch = e.touches[0];
            offsetX = touch.clientX - block.getBoundingClientRect().left;
            offsetY = touch.clientY - block.getBoundingClientRect().top;
            block.style.transform = 'scale(1.2) rotate(5deg)';
            block.style.opacity = '0.8';
            block.style.zIndex = '1000';
            trackEvent('block_touch_start', { value: block.dataset.value });
        });
        
        block.addEventListener('touchmove', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            const rect = cityCanvas.getBoundingClientRect();
            const x = touch.clientX - rect.left - offsetX;
            const y = touch.clientY - rect.top - offsetY;
            const snapSize = 10;
            const snappedX = Math.round(x / snapSize) * snapSize;
            const snappedY = Math.round(y / snapSize) * snapSize;
            const constrainedX = Math.max(0, Math.min(snappedX, rect.width - 55));
            const constrainedY = Math.max(0, Math.min(snappedY, rect.height - 55));
            block.style.position = 'absolute';
            block.style.left = `${constrainedX}px`;
            block.style.top = `${constrainedY}px`;
        });
        
        block.addEventListener('touchend', () => {
            block.style.transform = '';
            block.style.opacity = '';
            block.style.zIndex = '';
            if (!isOverlapping(parseInt(block.style.left), parseInt(block.style.top))) {
                handleBlockDrop(block);
            } else {
                showMessage("Cannot place block here; it overlaps with another block!");
                block.style.left = '';
                block.style.top = '';
                block.style.position = '';
                trackEvent('block_drop_failed', { reason: 'overlap' });
            }
            draggedBlock = null;
        });
        
        block.addEventListener('mouseenter', () => {
            block.style.transform = 'scale(1.1)';
        });
        
        block.addEventListener('mouseleave', () => {
            block.style.transform = '';
        });
        
        block.tabIndex = 0;
        block.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                if (!isOverlapping(parseInt(block.style.left) || 0, parseInt(block.style.top) || 0)) {
                    handleBlockDrop(block);
                } else {
                    showMessage("Cannot place block here; it overlaps with another block!");
                    trackEvent('block_drop_failed', { reason: 'overlap', input: 'keyboard' });
                }
            }
        });
        
        blocksWrapper.appendChild(block);
    }
    
    const extraBlocks = blocksContainer.querySelector('.extra-blocks');
    if (count > visualBlocks) {
        if (!extraBlocks) {
            const extra = document.createElement('div');
            extra.className = 'extra-blocks';
            extra.style.textAlign = 'center';
            extra.style.marginTop = '5px';
            extra.style.fontSize = '12px';
            extra.style.color = '#7f8c8d';
            blocksContainer.appendChild(extra);
        }
        blocksContainer.querySelector('.extra-blocks').textContent = `+${count - visualBlocks} more blocks`;
    } else if (extraBlocks) {
        extraBlocks.remove();
    }
    trackEvent('blocks_created', { count, visualBlocks });
}

// Handle block drop
function handleBlockDrop(block) {
    const value = parseInt(block.dataset.value);
    if (blocks < value) {
        showMessage(`You need ${value} blocks to place this!`);
        trackEvent('block_drop_failed', { reason: 'insufficient_blocks', required: value, available: blocks });
        return;
    }
    
    const rect = cityCanvas.getBoundingClientRect();
    const x = parseInt(block.style.left) || 0;
    const y = parseInt(block.style.top) || 0;
    if (isOverlapping(x, y)) {
        showMessage("Cannot place block here; it overlaps with another block!");
        block.style.left = '';
        block.style.top = '';
        block.style.position = '';
        trackEvent('block_drop_failed', { reason: 'overlap' });
        return;
    }
    
    blocks -= value;
    blockCountEl.textContent = blocks;
    
    const newBlock = document.createElement('div');
    newBlock.className = 'city-block';
    newBlock.style.background = block.style.background;
    newBlock.style.position = 'absolute';
    newBlock.style.left = `${Math.max(0, Math.min(x, rect.width - 55))}px`;
    newBlock.style.top = `${Math.max(0, Math.min(y, rect.height - 55))}px`;
    newBlock.innerHTML = block.innerHTML;
    newBlock.draggable = true;
    newBlock.dataset.value = value;
    newBlock.setAttribute('aria-label', 'Placed building block');
    newBlock.setAttribute('role', 'button');
    
    setupCityBlockEvents(newBlock);
    
    cityCanvas.appendChild(newBlock);
    playBuildSound();
    buildingsBuilt += value;
    
    buildingHistory.push({ element: newBlock, value: value });
    if (buildingHistory.length > MAX_HISTORY_STEPS) {
        buildingHistory.shift();
    }
    
    updateProgress();
    saveGameState();
    block.remove();
    trackEvent('block_placed', { value, x, y });
}

// Setup events for city blocks
function setupCityBlockEvents(block) {
    block.addEventListener('dragstart', (e) => {
        e.dataTransfer.setDragImage(dragImage, 0, 0);
        draggedBlock = block;
        const rect = block.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
        block.classList.add('dragging');
        block.style.opacity = '0.4';
        trackEvent('city_block_drag_start', { value: block.dataset.value });
    });
    
    block.addEventListener('dragend', () => {
        block.style.opacity = '1';
        block.classList.remove('dragging');
        const rect = cityCanvas.getBoundingClientRect();
        const x = parseInt(block.style.left);
        const y = parseInt(block.style.top);
        if (isOverlapping(x, y)) {
            showMessage("Cannot place block here; it overlaps with another block!");
            block.style.left = '0px';
            block.style.top = '0px';
            trackEvent('city_block_drop_failed', { reason: 'overlap' });
        }
        draggedBlock = null;
        saveGameState();
        trackEvent('city_block_drag_end');
    });
    
    block.addEventListener('touchstart', (e) => {
        e.preventDefault();
        draggedBlock = block;
        const touch = e.touches[0];
        offsetX = touch.clientX - block.getBoundingClientRect().left;
        offsetY = touch.clientY - block.getBoundingClientRect().top;
        block.classList.add('dragging');
        block.style.opacity = '0.4';
        trackEvent('city_block_touch_start', { value: block.dataset.value });
    });
    
    block.addEventListener('touchmove', (e) => {
        e.preventDefault();
        const touch = e.touches[0];
        const rect = cityCanvas.getBoundingClientRect();
        const x = touch.clientX - rect.left - offsetX;
        const y = touch.clientY - rect.top - offsetY;
        const snapSize = 10;
        const snappedX = Math.round(x / snapSize) * snapSize;
        const snappedY = Math.round(y / snapSize) * snapSize;
        block.style.left = `${Math.max(0, Math.min(snappedX, rect.width - 55))}px`;
        block.style.top = `${Math.max(0, Math.min(snappedY, rect.height - 55))}px`;
    });
    
    block.addEventListener('touchend', () => {
        block.style.opacity = '1';
        block.classList.remove('dragging');
        const x = parseInt(block.style.left);
        const y = parseInt(block.style.top);
        if (isOverlapping(x, y)) {
            showMessage("Cannot place block here; it overlaps with another block!");
            block.style.left = '0px';
            block.style.top = '0px';
            trackEvent('city_block_drop_failed', { reason: 'overlap' });
        }
        draggedBlock = null;
        saveGameState();
        trackEvent('city_block_touch_end');
    });
    
    block.tabIndex = 0;
    block.addEventListener('keydown', (e) => {
        let x = parseInt(block.style.left) || 0;
        let y = parseInt(block.style.top) || 0;
        const rect = cityCanvas.getBoundingClientRect();
        if (e.key === 'ArrowUp') y = Math.max(0, y - 10);
        if (e.key === 'ArrowDown') y = Math.min(rect.height - 55, y + 10);
        if (e.key === 'ArrowLeft') x = Math.max(0, x - 10);
        if (e.key === 'ArrowRight') x = Math.min(rect.width - 55, x + 10);
        if (!isOverlapping(x, y)) {
            block.style.left = `${x}px`;
            block.style.top = `${y}px`;
            trackEvent('city_block_moved', { x, y, input: 'keyboard' });
        } else {
            showMessage("Cannot move block here; it overlaps with another block!");
            trackEvent('city_block_move_failed', { reason: 'overlap', input: 'keyboard' });
        }
        saveGameState();
    });
}

// Undo last building action
function undoLastAction() {
    if (buildingHistory.length === 0) {
        showMessage("Nothing to undo!");
        trackEvent('undo_failed', { reason: 'no_history' });
        return;
    }
    
    const lastAction = buildingHistory.pop();
    const blocksToRestore = lastAction.value;
    
    if (lastAction.element && lastAction.element.parentNode === cityCanvas) {
        lastAction.element.remove();
    }
    
    blocks += blocksToRestore;
    blockCountEl.textContent = blocks;
    buildingsBuilt = Math.max(0, buildingsBuilt - blocksToRestore);
    updateProgress();
    saveGameState();
    
    showMessage(`Undo successful! ${blocksToRestore} blocks restored.`);
    playBuildSound();
    trackEvent('undo_action', { blocksRestored: blocksToRestore });
}

// Update progress bar
function updateProgress() {
    const progress = Math.min(100, buildingsBuilt / 2);
    progressFill.style.width = `${progress}%`;
    progressText.textContent = `${Math.floor(progress)}% Built`;
    trackEvent('progress_updated', { progress: Math.floor(progress) });
}

// Show message in speech bubble
function showMessage(message) {
    if (speechBubble) {
        speechBubble.textContent = message;
        speechBubble.style.animation = 'none';
        speechBubble.setAttribute('aria-live', 'polite');
        setTimeout(() => {
            speechBubble.style.animation = '';
        }, 10);
        trackEvent('message_displayed', { message });
    }
}

// Celebrate correct answer
function celebrate() {
    playCelebrationSound();
    
    const confettiCount = 20;
    for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = `${Math.random() * 100}%`;
        confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.animationDuration = `${Math.random() * 2 + 1}s`;
        confetti.style.transform = `rotate(${Math.random() * 360}deg)`;
        document.body.appendChild(confetti);
        
        setTimeout(() => confetti.remove(), 2000);
    }
    trackEvent('celebration_triggered', { confettiCount });
}

// Check for character unlocks
function checkUnlocks() {
    let unlockedNew = false;
    
    for (const character of characters) {
        if (!character.unlocked && buildingsBuilt >= character.requirement) {
            character.unlocked = true;
            unlockedNew = true;
            
            const unlockDiv = document.createElement('div');
            unlockDiv.className = 'unlock-message';
            unlockDiv.innerHTML = `Unlocked: ${character.emoji} ${character.name}!<br>${character.desc}`;
            unlockDiv.setAttribute('aria-live', 'assertive');
            document.body.appendChild(unlockDiv);
            
            setTimeout(() => unlockDiv.remove(), 3000);
            playUnlockSound();
            trackEvent('character_unlocked', { character: character.name, requirement: character.requirement });
        }
    }
    
    if (unlockedNew) {
        updateUnlockedCharacters();
        saveGameState();
    }
}

// Update unlocked characters display
function updateUnlockedCharacters() {
    if (unlockedCharactersEl) {
        unlockedCharactersEl.innerHTML = '';
        for (const character of characters) {
            if (character.unlocked) {
                const charDiv = document.createElement('div');
                charDiv.innerHTML = `${character.emoji} ${character.name}`;
                charDiv.style.margin = '5px';
                charDiv.style.fontSize = '14px';
                charDiv.setAttribute('aria-label', `Unlocked character: ${character.name}`);
                unlockedCharactersEl.appendChild(charDiv);
            }
        }
        trackEvent('unlocked_characters_updated', { unlocked: characters.filter(c => c.unlocked).map(c => c.name) });
    }
}

// Day/night cycle
function startDayNightCycle() {
    setInterval(() => {
        isDaytime = !isDaytime;
        document.body.classList.toggle('night-mode', !isDaytime);
        cityCanvas.style.transition = 'background-color 1s ease';
        cityCanvas.style.backgroundColor = isDaytime ? '#ecf0f1' : '#2c3e50';
        trackEvent('day_night_cycle', { isDaytime });
    }, 30000);
}

// Mini-game placeholder
function startMiniGame() {
    showMessage("Rainbow Run coming soon! Keep solving math problems for now!");
    trackEvent('minigame_triggered');
}

// Enhanced drag and drop setup
function setupEventListeners() {
    submitBtn.addEventListener('click', checkAnswer);
    answerInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') checkAnswer();
    });
    
    answerInput.addEventListener('input', () => {
        answerInput.value = answerInput.value.replace(/[^0-9]/g, '');
    });
    
    cityCanvas.addEventListener('dragover', (e) => {
        e.preventDefault();
        const rect = cityCanvas.getBoundingClientRect();
        const x = e.clientX - rect.left - 25;
        const y = e.clientY - rect.top - 25;
        const snapSize = 10;
        const snappedX = Math.round(x / snapSize) * snapSize;
        const snappedY = Math.round(y / snapSize) * snapSize;
        const constrainedX = Math.max(0, Math.min(snappedX, rect.width - 55));
        const constrainedY = Math.max(0, Math.min(snappedY, rect.height - 55));
        cityCanvas.style.backgroundColor = isOverlapping(constrainedX, constrainedY) ? '#f8d7da' : '#d5f5e3';
    });
    
    cityCanvas.addEventListener('dragleave', () => {
        cityCanvas.style.backgroundColor = isDaytime ? '#ecf0f1' : '#2c3e50';
    });
    
    cityCanvas.addEventListener('drop', (e) => {
        e.preventDefault();
        cityCanvas.style.backgroundColor = isDaytime ? '#ecf0f1' : '#2c3e50';
        
        const color = e.dataTransfer.getData('text/plain');
        const value = parseInt(e.dataTransfer.getData('value'));
        const emoji = e.dataTransfer.getData('emoji');
        
        if (blocks < value) {
            showMessage(`You need ${value} blocks to place this!`);
            trackEvent('block_drop_failed', { reason: 'insufficient_blocks', required: value, available: blocks });
            return;
        }
        
        const rect = cityCanvas.getBoundingClientRect();
        const x = e.clientX - rect.left - 25;
        const y = e.clientY - rect.top - 25;
        const snapSize = 10;
        const snappedX = Math.round(x / snapSize) * snapSize;
        const snappedY = Math.round(y / snapSize) * snapSize;
        const constrainedX = Math.max(0, Math.min(snappedX, rect.width - 55));
        const constrainedY = Math.max(0, Math.min(snappedY, rect.height - 55));
        
        if (isOverlapping(constrainedX, constrainedY)) {
            showMessage("Cannot place block here; it overlaps with another block!");
            trackEvent('block_drop_failed', { reason: 'overlap' });
            return;
        }
        
        blocks -= value;
        blockCountEl.textContent = blocks;
        
        const block = document.createElement('div');
        block.className = 'city-block';
        block.style.background = color;
        block.style.position = 'absolute';
        block.style.left = `${constrainedX}px`;
        block.style.top = `${constrainedY}px`;
        block.innerHTML = emoji;
        block.draggable = true;
        block.dataset.value = value;
        block.setAttribute('aria-label', 'Placed building block');
        block.setAttribute('role', 'button');
        
        setupCityBlockEvents(block);
        
        cityCanvas.appendChild(block);
        playBuildSound();
        buildingsBuilt += value;
        
        buildingHistory.push({ element: block, value: value });
        if (buildingHistory.length > MAX_HISTORY_STEPS) {
            buildingHistory.shift();
        }
        
        updateProgress();
        saveGameState();
        trackEvent('block_placed', { value, x: constrainedX, y: constrainedY });
    });
    
    cityCanvas.addEventListener('touchmove', (e) => {
        if (draggedBlock) {
            e.preventDefault();
            const touch = e.touches[0];
            const rect = cityCanvas.getBoundingClientRect();
            const x = touch.clientX - rect.left - offsetX;
            const y = touch.clientY - rect.top - offsetY;
            const snapSize = 10;
            const snappedX = Math.round(x / snapSize) * snapSize;
            const snappedY = Math.round(y / snapSize) * snapSize;
            draggedBlock.style.left = `${Math.max(0, Math.min(snappedX, rect.width - 55))}px`;
            draggedBlock.style.top = `${Math.max(0, Math.min(snappedY, rect.height - 55))}px`;
            cityCanvas.style.backgroundColor = isOverlapping(snappedX, snappedY) ? '#f8d7da' : '#d5f5e3';
        }
    });
    
    minigameBtn.addEventListener('click', startMiniGame);
    undoBtn.addEventListener('click', undoLastAction);
    resetBtn.addEventListener('click', resetGame);
    
    document.querySelectorAll('.template').forEach(template => {
        template.addEventListener('click', () => {
            const requiredBlocks = parseInt(template.dataset.blocks);
            if (blocks >= requiredBlocks) {
                blocks -= requiredBlocks;
                blockCountEl.textContent = blocks;
                showMessage(`Building a ${template.dataset.shape}...`);
                setTimeout(() => {
                    playBuildSound();
                    buildingsBuilt += requiredBlocks;
                    
                    buildingHistory.push({ value: requiredBlocks });
                    if (buildingHistory.length > MAX_HISTORY_STEPS) {
                        buildingHistory.shift();
                    }
                    
                    updateProgress();
                    saveGameState();
                    trackEvent('template_built', { shape: template.dataset.shape, blocks: requiredBlocks });
                }, 1000);
            } else {
                showMessage(`You need ${requiredBlocks - blocks} more blocks!`);
                trackEvent('template_build_failed', { shape: template.dataset.shape, required: requiredBlocks, available: blocks });
            }
        });
    });
}

// Start the game
window.addEventListener('DOMContentLoaded', initGame);